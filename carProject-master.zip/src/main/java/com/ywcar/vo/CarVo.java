package com.ywcar.vo;

public class CarVo {
	private int HIST_SQ;
	private String VHICHL_NM;
	private String VHICHL_ASORT_CD;
	private String VHICHL_DSTNC;
	private String VHICHL_REG_DT;
	private String VHICHL_REQ_DT;
	private String VHICHL_CMP_DT;
	private String VHICHL_UPD_CD;
	private String VHICHL_WRK_ID;
	private String VHICHL_CMPNT_CD;
	
	public int getHIST_SQ() {
		return HIST_SQ;
	}
	public void setHIST_SQ(int hIST_SQ) {
		HIST_SQ = hIST_SQ;
	}
	public String getVHICHL_NM() {
		return VHICHL_NM;
	}
	public void setVHICHL_NM(String vHICHL_NM) {
		VHICHL_NM = vHICHL_NM;
	}
	public String getVHICHL_ASORT_CD() {
		return VHICHL_ASORT_CD;
	}
	public void setVHICHL_ASORT_CD(String vHICHL_ASORT_CD) {
		VHICHL_ASORT_CD = vHICHL_ASORT_CD;
	}
	public String getVHICHL_DSTNC() {
		return VHICHL_DSTNC;
	}
	public void setVHICHL_DSTNC(String vHICHL_DSTNC) {
		VHICHL_DSTNC = vHICHL_DSTNC;
	}
	public String getVHICHL_REG_DT() {
		return VHICHL_REG_DT;
	}
	public void setVHICHL_REG_DT(String vHICHL_REG_DT) {
		VHICHL_REG_DT = vHICHL_REG_DT;
	}
	public String getVHICHL_REQ_DT() {
		return VHICHL_REQ_DT;
	}
	public void setVHICHL_REQ_DT(String vHICHL_REQ_DT) {
		VHICHL_REQ_DT = vHICHL_REQ_DT;
	}
	public String getVHICHL_CMP_DT() {
		return VHICHL_CMP_DT;
	}
	public void setVHICHL_CMP_DT(String vHICHL_CMP_DT) {
		VHICHL_CMP_DT = vHICHL_CMP_DT;
	}
	public String getVHICHL_UPD_CD() {
		return VHICHL_UPD_CD;
	}
	public void setVHICHL_UPD_CD(String vHICHL_UPD_CD) {
		VHICHL_UPD_CD = vHICHL_UPD_CD;
	}
	public String getVHICHL_WRK_ID() {
		return VHICHL_WRK_ID;
	}
	public void setVHICHL_WRK_ID(String vHICHL_WRK_ID) {
		VHICHL_WRK_ID = vHICHL_WRK_ID;
	}
	public String getVHICHL_CMPNT_CD() {
		return VHICHL_CMPNT_CD;
	}
	public void setVHICHL_CMPNT_CD(String vHICHL_CMPNT_CD) {
		VHICHL_CMPNT_CD = vHICHL_CMPNT_CD;
	}
	@Override
	public String toString() {
		return "[HIST_SQ=" + HIST_SQ + ", VHICHL_NM=" + VHICHL_NM
				+ ", VHICHL_ASORT_CD=" + VHICHL_ASORT_CD + ", VHICHL_DSTNC="
				+ VHICHL_DSTNC + ", VHICHL_REG_DT=" + VHICHL_REG_DT
				+ ", VHICHL_REQ_DT=" + VHICHL_REQ_DT + ", VHICHL_CMP_DT="
				+ VHICHL_CMP_DT + ", VHICHL_UPD_CD=" + VHICHL_UPD_CD
				+ ", VHICHL_WRK_ID=" + VHICHL_WRK_ID + ", VHICHL_CMPNT_CD="
				+ VHICHL_CMPNT_CD + "]";
	}
}
