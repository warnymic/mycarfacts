# History

## 0.1.7 (2013-12-16)
* Default to http: if window.location.protocol is not http: or https:

## 0.1.6 (2013-08-19)

## 0.1.5 (2013-08-19)

## 0.1.1 (2013-08-17)
* Add cache to JSONP call

## 0.1.0 (2013-06-23)
* First JS SDK on GitHub