## Development
* Ismail Elshareef
* Michael Bock \<mbock@edmunds.com\>
* You? Create a pull request!

## Patches and Suggestions?
* Email api@edmunds.com or open an [issue](https://github.com/EdmundsAPI/sdk-javascript).